
                   <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                2019 &copy; design by <a href="https://www.ainotek.com">ainotek</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

