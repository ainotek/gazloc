<!-- our partner -->
<section class="pt-120 pb-120 boxed-shadow">
    <div class="container">
        <div class="row">
            <div class="col">
                <!-- partner carosel inner -->
                <div class="partner-carousel-wrap">
                    <div class="partner-carousel owl-carousel">
                        <!-- single partner -->
                        <div class="single-partner">
                            <img src="{{asset('')}}/img/partner.png" alt="">
                        </div>
                        <!-- End of single partner -->

                        <!-- single partner -->
                        <div class="single-partner">
                            <img src="{{asset('')}}/img/partner.png" alt="">
                        </div>
                        <!-- End of single partner -->

                        <!-- single partner -->
                        <div class="single-partner">
                            <img src="{{asset('')}}/img/partner.png" alt="">
                        </div>
                        <!-- End of single partner -->

                        <!-- single partner -->
                        <div class="single-partner">
                            <img src="{{asset('')}}/img/partner.png" alt="">
                        </div>
                        <!-- End of single partner -->
                    </div>
                </div>
                <!--End of  partner carosel inner -->
            </div>
        </div>
    </div>
</section>
<!-- End of our partner -->
