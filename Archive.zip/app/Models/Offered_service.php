<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Offered_service extends Model
{
    //
}
