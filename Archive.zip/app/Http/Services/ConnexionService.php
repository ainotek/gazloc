<?php


namespace App\Http\Services;


class ConnexionService
{

}
